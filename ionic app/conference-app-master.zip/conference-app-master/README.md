# Conference App with Ionic 2

# Steps to use
* clone this repo
* npm install
* Install the required cordova plugins
* Then ```ionic build android``` or ```ionic build ios```

# Goodies?
It works with Lanyrd JSON Export. You just need to put the URL or JSON Export in the app and you are good to go!

# Based on Ionic 2 Beta 10