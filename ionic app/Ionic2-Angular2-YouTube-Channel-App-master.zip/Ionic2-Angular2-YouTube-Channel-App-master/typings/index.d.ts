/// <reference path="globals/es6-shim/index.d.ts" />
/// <reference path="globals/gapi.youtube/index.d.ts" />
/// <reference path="globals/gapi/index.d.ts" />
/// <reference path="globals/youtube/index.d.ts" />
