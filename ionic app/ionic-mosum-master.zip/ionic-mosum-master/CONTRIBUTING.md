### Contribution
Contributions are welcome!

See [features planned for future](https://github.com/aggarwalankush/ionic-mosum/issues/2) to get contributing ideas.

* Report issues
* Open pull request with improvements
* Spread the word

### License
ionic-mosum is available under the MIT license. See the LICENSE file for more info.
