module.exports = {
  compress: {
    drop_console: true
  }
};
