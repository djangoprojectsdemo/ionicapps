# Media Player App with Ionic 2

# Steps to use
* clone this repo
* npm install
* ionic state restore
* Add the required platform like ```ionic platform add android``` or ```ionic platform add ios```
* Then ```ionic build android``` or ```ionic build ios```

# Based on Ionic 2.3.0
