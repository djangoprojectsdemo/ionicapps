export class Person{
    name: string;
    surname: string;
    role: string;
    image: any;
}