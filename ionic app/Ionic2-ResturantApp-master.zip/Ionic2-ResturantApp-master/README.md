# Ionic 2 Sample App - Restaurant

A simple restaurant app which is developed on **Ionic 2** & **Angular 2**

### Screenshots

<a href="https://i.imgur.com/frJ2Lz9.jpg"><img src="https://i.imgur.com/frJ2Lz9.jpg" align="left" width="250"></a>
<a href="https://i.imgur.com/UsfPXv7.jpg"><img src="https://i.imgur.com/UsfPXv7.jpg" align="left" width="250" ></a>
<a href="https://i.imgur.com/OZQumcn.jpg"><img src="https://i.imgur.com/OZQumcn.jpg" align="left" width="250" ></a>
<a href="https://i.imgur.com/kKeAbMS.jpg"><img src="https://i.imgur.com/kKeAbMS.jpg" align="left" width="250" ></a>
<a href="https://i.imgur.com/RtRkMYF.jpg"><img src="https://i.imgur.com/RtRkMYF.jpg" align="left" width="250" ></a>
<a href="https://i.imgur.com/aW7UMtY.jpg"><img src="https://i.imgur.com/aW7UMtY.jpg" align="left" width="250" ></a>
<a href="http://i.imgur.com/dqTDljo.jpg"><img src="http://i.imgur.com/dqTDljo.jpg" align="left" width="250" ></a>
<a href="https://i.imgur.com/VqnY9zz.jpg"><img src="https://i.imgur.com/VqnY9zz.jpg" align="left" width="250" ></a>
