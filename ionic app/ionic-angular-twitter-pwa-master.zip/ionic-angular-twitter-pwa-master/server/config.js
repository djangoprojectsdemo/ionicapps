module.exports = {
    port: process.env.SERVER_PORT || 5000
}
