import { Component } from '@angular/core';

/**
 * Generated class for the MessageFabComponent component.
 *
 * See https://angular.io/docs/ts/latest/api/core/index/ComponentMetadata-class.html
 * for more info on Angular Components.
 */
@Component({
  selector: 'message-fab',
  templateUrl: 'message-fab.html'
})
export class MessageFabComponent {

  constructor() {
    console.log('Hello MessageFabComponent Component');
  }

}
