# Timer

## What is this?

Just a timer application written in Ionic 2.
