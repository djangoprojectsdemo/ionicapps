# ionic2-freshlypressed
A simple app using the ionic2 framework and freshly pressed api

This app makes a call to the freshly pressed api offered by wordpress and shows it on a screen. 

This is just a demo to illustrate the capabilities of Ionic2 framework.

#How to use:

Just clone the repo and give npm install.

(p.s: you need to have ionic 2 installed).

For more details please visit: http://tphangout.com/?p=113
