# Wordpress Client with Ionic 2

# Steps to use
* clone this repo
* npm install
* Install the required cordova plugins
* Then ```ionic build android``` or ```ionic build ios```

# Based on Ionic 2 Beta 10